SPDK Documentation
==================

The current version of the SPDK documentation can be found online at
http://www.spdk.io/doc/

Building the Documentation
==========================

To convert the documentation into HTML run `make` in the `doc`
directory.  The output will be located in `doc/output/html`. Before
running `make` ensure all pre-requisites are installed.  See
[Installing Prerequisites](http://www.spdk.io/doc/getting_started.html)
for more details.
